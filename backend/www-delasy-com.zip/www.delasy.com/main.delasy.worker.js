const securityHeaders = {
  'Content-Security-Policy': 'upgrade-insecure-requests',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block'
}

const handleRequest = async (req) => {
  const res = await fetch(req)
  const headers = new Headers(res.headers)

  if (headers.has('Content-Type') && !headers.get('Content-Type').includes('text/html')) {
    return new Response(res.body, {
      headers: headers,
      status: res.status,
      statusText: res.statusText
    })
  }

  Object.keys(securityHeaders).map((name) => {
    headers.set(name, securityHeaders[name])
  })

  return new Response(res.body, {
    headers: headers,
    status: res.status,
    statusText: res.statusText
  })
}

addEventListener('fetch', (event) => {
  event.respondWith(handleRequest(event.request))
})

